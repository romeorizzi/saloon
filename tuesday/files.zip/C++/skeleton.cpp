#include <cstdio>
#include <cstdlib>

static const int ZERO = 0;

static const int ONE = 1;

static const int TWO = 2;

static const int THEREE = 3;

static const int FOUR = 4;

static const int FIVE = 5;

static const int SIX = 6;

static const int SEVEN = 7;

static const int EIGHT = 8;

static const int NINE = 9;

static const int COMMA = 10;

void get_original_string(int string_length, int *string_over_alphabet_0123456789comma);

int tell_encoding_string_length();

int tell_encoding_string_ith_char(int i);

void get_encoded_string(int string_length, int *string_over_reduced_alphabet);

int tell_original_string_length();

int tell_original_string_ith_char(int i);

int main() {
    // checkpoint
    printf("%d\n", 0);
    // read choice
    static int choice;
    fflush(stdout);
    scanf("%d", &choice);
    // if choice {...} else {...}
    if (choice) {
        // read N
        static int N;
        fflush(stdout);
        scanf("%d", &N);
        // for i to N {...}
        static int *original_string;
        original_string = new int[N];
        for (int i = 0; i < N; i++) {
            // read original_string[i]
            fflush(stdout);
            scanf("%d", &original_string[i]);
        }
        // call get_original_string(N, original_string)
        get_original_string(N, original_string);
        // call blown_up_N = tell_encoding_string_length()
        static int blown_up_N;
        blown_up_N = tell_encoding_string_length();
        // write blown_up_N
        printf("%d\n", blown_up_N);
        // for i to blown_up_N {...}
        for (int i = 0; i < blown_up_N; i++) {
            // call char = tell_encoding_string_ith_char(i)
            static int char;
            char = tell_encoding_string_ith_char(i);
            // write char
            printf("%d\n", char);
        }
    } else {
        // read blown_up_N
        static int blown_up_N;
        fflush(stdout);
        scanf("%d", &blown_up_N);
        // for i to blown_up_N {...}
        static int *encoding_string;
        encoding_string = new int[blown_up_N];
        for (int i = 0; i < blown_up_N; i++) {
            // read encoding_string[i]
            fflush(stdout);
            scanf("%d", &encoding_string[i]);
        }
        // call get_encoded_string(blown_up_N, encoding_string)
        get_encoded_string(blown_up_N, encoding_string);
        // call original_N = tell_original_string_length()
        static int original_N;
        original_N = tell_original_string_length();
        // write original_N
        printf("%d\n", original_N);
        // for i to original_N {...}
        for (int i = 0; i < original_N; i++) {
            // call char = tell_original_string_ith_char(i)
            static int char;
            char = tell_original_string_ith_char(i);
            // write char
            printf("%d\n", char);
        }
    }
    // exit
    exit(0);
}
