static const int ZERO = 0;

static const int ONE = 1;

static const int TWO = 2;

static const int THEREE = 3;

static const int FOUR = 4;

static const int FIVE = 5;

static const int SIX = 6;

static const int SEVEN = 7;

static const int EIGHT = 8;

static const int NINE = 9;

static const int COMMA = 10;

void get_original_string(int string_length, int *string_over_alphabet_0123456789comma) {
    // TODO
}
int tell_encoding_string_length() {
    // TODO
    return 42;
}
int tell_encoding_string_ith_char(int i) {
    // TODO
    return 42;
}
void get_encoded_string(int string_length, int *string_over_reduced_alphabet) {
    // TODO
}
int tell_original_string_length() {
    // TODO
    return 42;
}
int tell_original_string_ith_char(int i) {
    // TODO
    return 42;
}
