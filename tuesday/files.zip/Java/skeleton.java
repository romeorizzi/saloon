import java.util.Scanner;

abstract class Skeleton {
    private static final Scanner in = new Scanner(System.in);

    private static final int ZERO = 0;
    private static final int ONE = 1;
    private static final int TWO = 2;
    private static final int THEREE = 3;
    private static final int FOUR = 4;
    private static final int FIVE = 5;
    private static final int SIX = 6;
    private static final int SEVEN = 7;
    private static final int EIGHT = 8;
    private static final int NINE = 9;
    private static final int COMMA = 10;

    abstract void get_original_string(int string_length, int string_over_alphabet_0123456789comma[]);

    abstract int tell_encoding_string_length();

    abstract int tell_encoding_string_ith_char(int i);

    abstract void get_encoded_string(int string_length, int string_over_reduced_alphabet[]);

    abstract int tell_original_string_length();

    abstract int tell_original_string_ith_char(int i);

    public static void main(String[] args) {
        Solution __solution = new Solution();

        // checkpoint
        System.out.printf("%d\n", 0);
        // read choice
        int choice;
        System.out.flush();
        choice = in.nextInt();
        // if choice {...} else {...}
        if (choice != 0) {
            // read N
            int N;
            System.out.flush();
            N = in.nextInt();
            // for i to N {...}
            int[] original_string;
            original_string = new int[N];
            for (int i = 0; i < N; i++) {
                // read original_string[i]
                System.out.flush();
                original_string[i] = in.nextInt();
            }
            // call get_original_string(N, original_string)
            __solution.get_original_string(N, original_string);
            // call blown_up_N = tell_encoding_string_length()
            int blown_up_N;
            blown_up_N = __solution.tell_encoding_string_length();
            // write blown_up_N
            System.out.printf("%d\n", blown_up_N);
            // for i to blown_up_N {...}
            for (int i = 0; i < blown_up_N; i++) {
                // call char = tell_encoding_string_ith_char(i)
                int char;
                char = __solution.tell_encoding_string_ith_char(i);
                // write char
                System.out.printf("%d\n", char);
            }
        } else {
            // read blown_up_N
            int blown_up_N;
            System.out.flush();
            blown_up_N = in.nextInt();
            // for i to blown_up_N {...}
            int[] encoding_string;
            encoding_string = new int[blown_up_N];
            for (int i = 0; i < blown_up_N; i++) {
                // read encoding_string[i]
                System.out.flush();
                encoding_string[i] = in.nextInt();
            }
            // call get_encoded_string(blown_up_N, encoding_string)
            __solution.get_encoded_string(blown_up_N, encoding_string);
            // call original_N = tell_original_string_length()
            int original_N;
            original_N = __solution.tell_original_string_length();
            // write original_N
            System.out.printf("%d\n", original_N);
            // for i to original_N {...}
            for (int i = 0; i < original_N; i++) {
                // call char = tell_original_string_ith_char(i)
                int char;
                char = __solution.tell_original_string_ith_char(i);
                // write char
                System.out.printf("%d\n", char);
            }
        }
        // exit
        System.exit(0);
    }
}
