class Solution extends Skeleton {

    void get_original_string(int string_length, int string_over_alphabet_0123456789comma[]) {
        // TODO
    }
    int tell_encoding_string_length() {
        // TODO
        return 42;
    }
    int tell_encoding_string_ith_char(int i) {
        // TODO
        return 42;
    }
    void get_encoded_string(int string_length, int string_over_reduced_alphabet[]) {
        // TODO
    }
    int tell_original_string_length() {
        // TODO
        return 42;
    }
    int tell_original_string_ith_char(int i) {
        // TODO
        return 42;
    }
}
