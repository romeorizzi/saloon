import os as _os

ZERO = 0

ONE = 1

TWO = 2

THEREE = 3

FOUR = 4

FIVE = 5

SIX = 6

SEVEN = 7

EIGHT = 8

NINE = 9

COMMA = 10

def main(_solution):
    # checkpoint
    print(0)
    # read choice
    print(end="", flush=True)
    [choice] = map(int, input().split())
    # if choice {...} else {...}
    if choice:
        # read N
        print(end="", flush=True)
        [N] = map(int, input().split())
        # for i to N {...}
        original_string = [None] * N
        for i in range(N):
            # read original_string[i]
            print(end="", flush=True)
            [original_string[i]] = map(int, input().split())
        # call get_original_string(N, original_string)
        _solution.get_original_string(N, original_string)
        # call blown_up_N = tell_encoding_string_length()
        blown_up_N = int(_solution.tell_encoding_string_length())
        # write blown_up_N
        print(blown_up_N)
        # for i to blown_up_N {...}
        for i in range(blown_up_N):
            # call char = tell_encoding_string_ith_char(i)
            char = int(_solution.tell_encoding_string_ith_char(i))
            # write char
            print(char)
    else:
        # read blown_up_N
        print(end="", flush=True)
        [blown_up_N] = map(int, input().split())
        # for i to blown_up_N {...}
        encoding_string = [None] * blown_up_N
        for i in range(blown_up_N):
            # read encoding_string[i]
            print(end="", flush=True)
            [encoding_string[i]] = map(int, input().split())
        # call get_encoded_string(blown_up_N, encoding_string)
        _solution.get_encoded_string(blown_up_N, encoding_string)
        # call original_N = tell_original_string_length()
        original_N = int(_solution.tell_original_string_length())
        # write original_N
        print(original_N)
        # for i to original_N {...}
        for i in range(original_N):
            # call char = tell_original_string_ith_char(i)
            char = int(_solution.tell_original_string_ith_char(i))
            # write char
            print(char)
    # exit
    print(end="", flush=True)
    _os._exit(0)


if __name__ == '__main__':
    import sys
    import runpy
    
    if len(sys.argv) != 2:
        print("Usage: {} <solution>".format(sys.argv[0]))
    
    class Wrapper: pass 
    solution = Wrapper()
    solution.__dict__ = runpy.run_path(sys.argv[1])
    main(solution)

