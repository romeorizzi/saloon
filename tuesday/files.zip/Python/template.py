def get_original_string(string_length, string_over_alphabet_0123456789comma):
    # TODO
    pass

def tell_encoding_string_length():
    # TODO
    return 42
    pass

def tell_encoding_string_ith_char(i):
    # TODO
    return 42
    pass

def get_encoded_string(string_length, string_over_reduced_alphabet):
    # TODO
    pass

def tell_original_string_length():
    # TODO
    return 42
    pass

def tell_original_string_ith_char(i):
    # TODO
    return 42
    pass

