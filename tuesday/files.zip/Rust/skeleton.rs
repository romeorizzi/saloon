mod solution;
use std::io::Write;

macro_rules! readln {
    ($($var:expr),*) => {{
        let mut buf = String::new();
        std::io::stdin().read_line(&mut buf).unwrap();
        let parts: Vec<&str> = buf.trim().split(" ").collect();
        let mut i: usize = 0;
        $(
            assert!(i < parts.len(), "input format incorrect: too few values on this line"); 
            $var = parts[i].parse().unwrap();
            i += 1;
        )*
        assert!(i == parts.len(), "input format incorrect: too many values on the line")
    }};
}

const ZERO: i64 = 0;
const ONE: i64 = 1;
const TWO: i64 = 2;
const THEREE: i64 = 3;
const FOUR: i64 = 4;
const FIVE: i64 = 5;
const SIX: i64 = 6;
const SEVEN: i64 = 7;
const EIGHT: i64 = 8;
const NINE: i64 = 9;
const COMMA: i64 = 10;

fn main() {
    // checkpoint
    println!("{}", 0);
    // read choice
    let choice: i64;
    std::io::stdout().flush().unwrap();
    readln!(choice);
    // if choice {...} else {...}
    if choice != 0 {
        // read N
        let N: i64;
        std::io::stdout().flush().unwrap();
        readln!(N);
        // for i to N {...}
        let mut original_string: Vec<i64> = Vec::new();
        original_string.resize(N as usize, 0);
        for i in 0..N {
            // read original_string[i]
            std::io::stdout().flush().unwrap();
            readln!(original_string[i as usize]);
        }
        // call get_original_string(N, original_string)
        solution::get_original_string(N, original_string);
        // call blown_up_N = tell_encoding_string_length()
        let blown_up_N: i64;
        blown_up_N = solution::tell_encoding_string_length();
        // write blown_up_N
        println!("{}", blown_up_N);
        // for i to blown_up_N {...}
        for i in 0..blown_up_N {
            // call char = tell_encoding_string_ith_char(i)
            let char: i64;
            char = solution::tell_encoding_string_ith_char(i);
            // write char
            println!("{}", char);
        }
    } else {
        // read blown_up_N
        let blown_up_N: i64;
        std::io::stdout().flush().unwrap();
        readln!(blown_up_N);
        // for i to blown_up_N {...}
        let mut encoding_string: Vec<i64> = Vec::new();
        encoding_string.resize(blown_up_N as usize, 0);
        for i in 0..blown_up_N {
            // read encoding_string[i]
            std::io::stdout().flush().unwrap();
            readln!(encoding_string[i as usize]);
        }
        // call get_encoded_string(blown_up_N, encoding_string)
        solution::get_encoded_string(blown_up_N, encoding_string);
        // call original_N = tell_original_string_length()
        let original_N: i64;
        original_N = solution::tell_original_string_length();
        // write original_N
        println!("{}", original_N);
        // for i to original_N {...}
        for i in 0..original_N {
            // call char = tell_original_string_ith_char(i)
            let char: i64;
            char = solution::tell_original_string_ith_char(i);
            // write char
            println!("{}", char);
        }
    }
    // exit
    std::process::exit(0);
}
