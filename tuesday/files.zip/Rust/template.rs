const ZERO: i64 = 0;
const ONE: i64 = 1;
const TWO: i64 = 2;
const THEREE: i64 = 3;
const FOUR: i64 = 4;
const FIVE: i64 = 5;
const SIX: i64 = 6;
const SEVEN: i64 = 7;
const EIGHT: i64 = 8;
const NINE: i64 = 9;
const COMMA: i64 = 10;

pub fn get_original_string(string_length: i64, string_over_alphabet_0123456789comma: Vec<i64>)  {
    // TODO
}
pub fn tell_encoding_string_length() -> i64 {
    // TODO
    return 42;
}
pub fn tell_encoding_string_ith_char(i: i64) -> i64 {
    // TODO
    return 42;
}
pub fn get_encoded_string(string_length: i64, string_over_reduced_alphabet: Vec<i64>)  {
    // TODO
}
pub fn tell_original_string_length() -> i64 {
    // TODO
    return 42;
}
pub fn tell_original_string_ith_char(i: i64) -> i64 {
    // TODO
    return 42;
}
