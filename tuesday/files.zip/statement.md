# Saloon ultimate: just one key!

## General setting of the sequel (this is the first episode):

You have a part-time job in a saloon.
The job is flexible and asks you to play the piano, clean the floor (which is where you actually get your reward), but also to mantain the records of the bills. This last is the most challenging part in that, it is often impossible the custumers to pay their bills in many situations (drunk too beer or whisky, holding a gun bigger than that of the sceriff, passed away in a shooting, lost everything at the card table, ...).
The frequent shootings do not scare you in that, as we said, you are also the one who plays the piano. They do affect your credits recording activity however in that, while initially you had the ten digits plus a comma key on your typewriter keyboard, it may happen some days that, because of a shooting, some keys are gone and you must organize yourself to cope with the one left in the meanwhile you wait for the repair team which only works at night when the saloon closes (you are also the part-time man of the repair team).

## In this episode:

Today is first day of your working week. A very odinary day, just a quiet shooting in which the sceriff has been killed. Ah, you lost the '6' key of your keyboard. Can you still do your job?


### Goals 

Questo problema ti chiede di riuscire a ricostruire correttamente la sequenza.
Ma possiamo anche chiederti di farlo con efficienza. Per efficienza intendiamo che la quantità di inchiostro che vai a consumare non cresca troppo rispetto alla quantità di inchistro che avresti utilizzato potendoti avvalere dei tuoi 11 tasti (10 cifre più la virgola) nella dotazione standar.

- `correct`
- `correct-linear`
- `correct-linear-small-constant`


